﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmirhanErgen_G191210389
{
    public class Buzdolabı: Urun
    {
        string IcHacim;
        public string ıcHacim
        {
            get { return IcHacim; }
            set { IcHacim = value; }
        }
        string EnerjiSınıfı;
        public string enerjiSınıfı
        {
            get { return EnerjiSınıfı; }
            set { EnerjiSınıfı = value; }
        }

        public Buzdolabı()
        {

            lock (randomcu)
            {
                stokAdedi = rnd.Next(1, 100);
            }
            ad = "Siemens";
            enerjiSınıfı = "A+++";
            hamFiyat = 4789;
            ıcHacim = "86x186x88";
            ozellik = "Süper dondurma, Süper soğutma, Multiairflow, Buzmatik,Emniyetli cam raf, Hyperfresh plus bölme, FreshSense, Tatil modu, Yanlan LED iç aydınlatma";
            secilenAdet = 1;


        }
        public override int KdvUygula(int a)
        {
            a = (hamFiyat + (hamFiyat * 5) / 100) * secilenAdet;

            return a;
        }
    }
}
