#ifndef _BRICK_HPP__
#define _BRICK_HPP__

#define BRICK_SCALE_FACTOR_X        (0.35)
#define BRICK_SCALE_FACTOR_Y        (0.35)
#define BRICKS_PER_ROW              (6)
#define NUMBER_OF_BRICK_ROWS        (6)
#define DISTANCE_BETWEEN_BRICKS     (93) // px
#define BRICK_CHUNK_STARTING_X      (70) // px
#define BRICK_CHUNK_STARTING_Y      (60) // px
#define DISTANCE_BETWEEN_BRICK_ROWS (20) // px
#define TOTAL_BRICKS                (BRICKS_PER_ROW * NUMBER_OF_BRICK_ROWS)

#include "Element.hpp"

class Brick : public Element {
    public:
        // members
        int textureID;
        Texture crackedTexture;
        bool isBallHit;

                // TODO: get thsee cracked things
        const String allCrackedSkins[ARRAY_LENGTH] = {
        "./Dependencies/bin/resimler/Bricks/brick_blue_small_cracked.png", // Blue Cracked Brick
        "./Dependencies/bin/resimler/Bricks/brick_green_small_cracked.png", // Green Cracked Brick
        "./Dependencies/bin/resimler/Bricks/brick_pink_small_cracked.png", // Pink Cracked Brick
        "./Dependencies/bin/resimler/Bricks/brick_violet_small_cracked.png", // Violet Cracked Brick
        "./Dependencies/bin/resimler/Bricks/brick_yellow_small_cracked.png", // Yellow Cracked Brick
        "./Dependencies/bin/resimler/Bricks/brick_yellow_small_cracked.png" // Pink Cracked Brick
        };

        // methods
        Brick( Sprite s, int brickTextureID );
        
        void switchState();
        void destroy();
        void crack();
};


#endif // _BRICK_HPP__
