#ifndef _ELEMENT_HPP__
#define _ELEMENT_HPP__
#define ARRAY_LENGTH (6)

#include <SFML/Graphics.hpp>
#include <string>
#include <random>

using namespace sf;

class Element {
public:
  Element(Sprite s);
  Element();
  Sprite getSprite();
  Vector2f getPosition();
  FloatRect getGlobalBounds();
  void setPosition( int x, int y );

protected:
  Sprite sprite;
};


#endif // _ELEMENT_HPP__
