#ifndef __TEXTURES_H_
#define __TEXTURES_H_
#define ARRAY_LENGTH (6)

#include <SFML/Graphics.hpp>
#include <string>
using namespace sf;

#define GAME_BACKGROUND_IMAGE ("./Dependencies/bin/resimler/Background/background.jpg")





#endif // __TEXTURES_H_
