﻿/*
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2014-2015 BAHAR DÖNEMİ
**	
**				ÖĞRENCİ ADI............:EmirhanERGEN
**				ÖĞRENCİ NUMARASI.......:G191210389
**              DERSİN ALINDIĞI GRUP...:2. Öğretim C
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmirhanERGEN_G191210389_PRJ
{
    public class AtikKutusu:IAtikKutusu
    {
        int _dolulukOrani;


        public int BosaltmaPuani { get; set; }

        public int Kapasite { get; set; }

        public int DoluHacim { get; set; }

        public int DolulukOrani
        {
            get { return (100 * DoluHacim / Kapasite); }
            set { _dolulukOrani = value; }
        }

        public bool Bosalt()
        {
            if (DolulukOrani >= 75) return true;
            return false;
        }

        public bool Ekle(Atik atik)
        {
            if (atik.Hacim <= (Kapasite - DoluHacim)) return true;
            return false;
        }
    }
}
