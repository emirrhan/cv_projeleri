#ifndef _BALL_HPP_
#define _BALL_HPP_

#define BALL_STARTING_POSITION_X (281)
#define BALL_STARTING_POSITION_Y (872)
#define BALL_SCALE_FACTOR_X      (0.075)
#define BALL_SCALE_FACTOR_Y      (0.075)
#define BALL_LENGTH_X            (370 * BALL_SCALE_FACTOR_X)

#include "DynamicElement.hpp"

class Ball : public DynamicElement {
public:
  // members
    int textureID;
    bool isMoving;
    int8_t directionX = 5;
    int8_t directionY = -5;
  // methods
    Ball( Sprite s, int ballTextureID );
};

#endif // _BALL_HPP_

