export const apiKey = "8f485d7c62b34fb08796aedb0e6d4bac";
export const rootApiUrl = "https://api.spoonacular.com";
