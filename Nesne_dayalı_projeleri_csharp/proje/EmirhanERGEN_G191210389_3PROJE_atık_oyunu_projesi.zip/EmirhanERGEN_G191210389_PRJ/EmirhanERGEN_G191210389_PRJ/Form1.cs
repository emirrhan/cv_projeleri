﻿/*
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2014-2015 BAHAR DÖNEMİ
**	
**				ÖĞRENCİ ADI............:EmirhanERGEN
**				ÖĞRENCİ NUMARASI.......:G191210389
**              DERSİN ALINDIĞI GRUP...:2. Öğretim C
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmirhanERGEN_G191210389_PRJ
{
    public partial class Form1 : Form
    {
        //Atnklarımızın hacimleri resimleri boşaltım puanları kısacası üretim alanı
        Atik randomAtik;
        List<Button> atikKutusuButonlari = new List<Button>();
        List<Atik> atikListesi = new List<Atik>();
        //Atıklarınkların hacimleri ve Bin klasöründeki resim isimleri ve sınıfları organik metal kagit cam
        Atik domates = new Domates(150, Image.FromFile("Domates.png"), "Domates", "organik");
        Atik salatalik = new Salatalik(120, Image.FromFile("Salatalık.png"), "Salatalik", "organik");
        Atik camSise = new CamSise(600, Image.FromFile("Cam Şişe.png"), "Cam Şişe", "cam");
        Atik bardak = new Bardak(250, Image.FromFile("Bardak.png"), "Bardak", "cam");
        Atik kolaKutusu = new KolaKutusu(350, Image.FromFile("Kola Kutusu.png"), "Kola Kutusu", "metal");
        Atik salcaKutusu = new SalcaKutusu(550, Image.FromFile("Salça Kutusu.png"), "Salca Kutusu", "metal");
        Atik dergi = new Dergi(200, Image.FromFile("Dergi.png"), "Dergi", "kagit");
        Atik gazete = new Gazete(250, Image.FromFile("Gazate.png"), "Gazete", "kagit");
        //Atık kutuları
        AtikKutusu organikAtikKutusu = new OrganikAtikKutusu(0, 700, 0, 0);
        AtikKutusu camAtikKutusu = new CamAtikKutusu(600, 2200, 0, 0);
        AtikKutusu kagitAtikKutusu = new KagitAtikKutusu(1000, 1200, 0, 0);
        AtikKutusu metalAtikKutusu = new MetalAtikKutusu(800, 2300, 0, 0);
        public int puan = 0;
        public int kronometre = 0;
        public Form1()
        {
            InitializeComponent();
        }
        //Form Yüklenme Aşaması
        private void Form1_Load(object sender, EventArgs e)
        {
            AtikKutusuAktifDeaktif(atikKutusuButonlari, false);
            AtikEkleme();
        }
        //-----------------------------------------------------------------------
        //Oluşturmuş oldugum fonksiyonlar
        public void AtikKutusuAktifDeaktif(List<Button> bttns, bool config)
        {
            ButonlariEkleme();
            foreach (var btn in bttns)
            {
                btn.Enabled = config;
            }
        }
        public void DolumGuncelle()
        {
            organikDolum.Value = organikAtikKutusu.DolulukOrani;
            kagıtDolum.Value = kagitAtikKutusu.DolulukOrani;
            camDolum.Value = camAtikKutusu.DolulukOrani;
            metalDolum.Value = metalAtikKutusu.DolulukOrani;
        }
        public void DoluHacimSifirla()
        {
            organikAtikKutusu.DoluHacim = 0;
            kagitAtikKutusu.DoluHacim = 0;
            camAtikKutusu.DoluHacim = 0;
            metalAtikKutusu.DoluHacim = 0;
        }
        private void ButonlariEkleme()
        {
            atikKutusuButonlari.Add(organikEkle);
            atikKutusuButonlari.Add(organikBosalt);
            atikKutusuButonlari.Add(kagıtEkle);
            atikKutusuButonlari.Add(kagıtBosalt);
            atikKutusuButonlari.Add(camEkle);
            atikKutusuButonlari.Add(camBosalt);
            atikKutusuButonlari.Add(metalEkle);
            atikKutusuButonlari.Add(metalBosalt);
        }
        public void AtikEkleme()
        {
            atikListesi.Add(domates);
            atikListesi.Add(salatalik);
            atikListesi.Add(dergi);
            atikListesi.Add(gazete);
            atikListesi.Add(camSise);
            atikListesi.Add(bardak);
            atikListesi.Add(kolaKutusu);
            atikListesi.Add(salcaKutusu);
            
        }
        public Atik RandomUretim(List<Atik> atik)
        {
            // 200milisaniye askıya almak için
            Thread.Sleep(200);
            int randomSayi = new Random().Next(0, 8);
            resimBox.Image = atik[randomSayi].Image;
            return atik[randomSayi];
        }
        public void ListboxSifirla()
        {
            listBox1Organik.Items.Clear();
            listBox2Kagit.Items.Clear();
            listBox3Cam.Items.Clear();
            listBox4Metal.Items.Clear();
        }
        public void PuaniGuncelle()
        {
            puan = puan + randomAtik.Hacim;
            Label2puan.Text = Convert.ToString(puan);
        }
        //-----------------------------------------------------------------------
        //-----------------------------------------------------------------------

        /*Yeni Oyun basıldıgında oluşan seneryolar
         1-kronometremiz 60 a kurulur 
         2-dolum barlarımız sıfırlanır 
         3-listboxlarımız sıfırlanır
         4-atık kutularımız oluşur
         5-gerekli butonların aktifligi ve aktif olmaması saglanır
         6-puan tablomuz sıfırlanır
         7-kronometremiz geriye dogru saymaya başlar
         */
        //-----------------------------------------------------------------------

        private void buttonYeniOyun_Click(object sender, EventArgs e)
        {
            kronometre = 60;
            puan = 0;
            DoluHacimSifirla();
            ListboxSifirla();
            DolumGuncelle();
            randomAtik = RandomUretim(atikListesi);
            AtikKutusuAktifDeaktif(atikKutusuButonlari, true);
            basla.Enabled = false;
            Label2puan.Text = Convert.ToString(puan);
            timerKronometre.Start();
        }
        /*Çıkış butonuna basıldıgında oluşan seneryolar
         1-Evet hayır sorulu bir message box ekrana basar bu eksana timerı durdurur ve sorunun yanıtlanmasını bekler 
         2-Evet ise çıkış yapar 
         3-Hayır ise birşey degişmez ve timer kaldıgı yerden devam eder
         */
        private void buttonCikis_Click(object sender, EventArgs e)
        {
            timerKronometre.Stop();
            DialogResult secenek = MessageBox.Show("Gerçekten çıkmak istiyormusunuz","Çıkış", MessageBoxButtons.YesNo,MessageBoxIcon.Question);
            if (secenek==DialogResult.Yes)
            {
                this.Close();
            }
            if (secenek == DialogResult.No)
            {
                timerKronometre.Start();
            }
        }
        private void buttonEkleOrganik_Click(object sender, EventArgs e)
        {
            if ((randomAtik.Equals(domates) || randomAtik.Equals(salatalik)) && organikAtikKutusu.Ekle(randomAtik))
            {
                listBox1Organik.Items.Add(randomAtik.ToString());
                organikAtikKutusu.DoluHacim = organikAtikKutusu.DoluHacim + randomAtik.Hacim;
                DolumGuncelle();
                PuaniGuncelle();
                randomAtik = RandomUretim(atikListesi);
            }
        }

        private void buttonBosaltOrganik_Click(object sender, EventArgs e)
        {
            if (organikAtikKutusu.Bosalt())
            {
                kronometre = kronometre + 3;
                puan = puan + organikAtikKutusu.BosaltmaPuani;
                listBox1Organik.Items.Clear();
                organikAtikKutusu.DoluHacim = 0;
                DolumGuncelle();
                Label2puan.Text = Convert.ToString(puan);

            }
        }
        private void buttonEkleKagit_Click(object sender, EventArgs e)
        {
            if ((randomAtik.Equals(dergi) || randomAtik.Equals(gazete)) && kagitAtikKutusu.Ekle(randomAtik))
            {
                listBox2Kagit.Items.Add(randomAtik.ToString());
                kagitAtikKutusu.DoluHacim = kagitAtikKutusu.DoluHacim + randomAtik.Hacim;
                DolumGuncelle();
                PuaniGuncelle();
                randomAtik = RandomUretim(atikListesi);
            }
        }
        private void buttonBosaltKagit_Click(object sender, EventArgs e)
        {
            if (kagitAtikKutusu.Bosalt())
            {
                kronometre = kronometre + 3;
                puan = puan + kagitAtikKutusu.BosaltmaPuani;
                listBox2Kagit.Items.Clear();
                kagitAtikKutusu.DoluHacim = 0;
                DolumGuncelle();
                Label2puan.Text = Convert.ToString(puan);

            }
        }
        private void buttonEkleCam_Click(object sender, EventArgs e)
        {
            if ((randomAtik.Equals(bardak) || randomAtik.Equals(camSise)) && camAtikKutusu.Ekle(randomAtik))
            {
                listBox3Cam.Items.Add(randomAtik.ToString());
                camAtikKutusu.DoluHacim = camAtikKutusu.DoluHacim + randomAtik.Hacim;
                DolumGuncelle();
                PuaniGuncelle();
                randomAtik = RandomUretim(atikListesi);
            }
        }
        private void buttonBosaltCam_Click(object sender, EventArgs e)
        {
            if (camAtikKutusu.Bosalt())
            {
                kronometre = kronometre + 3;
                puan = puan + camAtikKutusu.BosaltmaPuani;
                listBox3Cam.Items.Clear();
                camAtikKutusu.DoluHacim = 0;
                DolumGuncelle();
                Label2puan.Text = Convert.ToString(puan);

            }
        }
        private void buttonEkleMetal_Click(object sender, EventArgs e)
        {
            if ((randomAtik.Equals(kolaKutusu) || randomAtik.Equals(salcaKutusu)) && metalAtikKutusu.Ekle(randomAtik))
            {
                listBox4Metal.Items.Add(randomAtik.ToString());
                metalAtikKutusu.DoluHacim = metalAtikKutusu.DoluHacim + randomAtik.Hacim;
                DolumGuncelle();
                PuaniGuncelle();
                randomAtik = RandomUretim(atikListesi);
            }
        }

        private void buttonBosaltMetal_Click(object sender, EventArgs e)
        {
            if (metalAtikKutusu.Bosalt())
            {
                kronometre = kronometre + 3;
                puan = puan + metalAtikKutusu.BosaltmaPuani;
                listBox4Metal.Items.Clear();
                metalAtikKutusu.DoluHacim = 0;
                DolumGuncelle();
                Label2puan.Text = Convert.ToString(puan);
            }
        }

        private void timer1KronometreTick_1(object sender, EventArgs e)
        {
            kronometre = kronometre - 1;
            Label1kronometre.Text = Convert.ToString(kronometre);
            if (kronometre == 0)
            {
                timerKronometre.Stop();
                AtikKutusuAktifDeaktif(atikKutusuButonlari, false);
                DolumGuncelle();
                basla.Enabled = true;
                MessageBox.Show($"Tebrikler {puan} Puanla Bitirdiniz!");
            }
        }
        
    }
}
