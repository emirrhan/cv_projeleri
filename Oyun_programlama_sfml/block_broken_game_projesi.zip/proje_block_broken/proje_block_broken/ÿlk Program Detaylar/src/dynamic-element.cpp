#include "../include/DynamicElement.hpp"

DynamicElement::DynamicElement( Sprite s) : Element( s ) {

}

DynamicElement::DynamicElement() {

}

void DynamicElement::move( int x, int y) {
   sprite.move(x,y);
}
