#include "../include/background.hpp"

Background::Background( Sprite s ) : Element( s ) {

}