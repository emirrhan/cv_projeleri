--
-- PostgreSQL database dump
--

-- Dumped from database version 11.9
-- Dumped by pg_dump version 13.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

--
-- Name: admin; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admin (
    email text NOT NULL,
    password text NOT NULL,
    contact_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.admin OWNER TO postgres;

--
-- Name: city; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.city (
    city_id integer NOT NULL,
    city_name text NOT NULL
);


ALTER TABLE public.city OWNER TO postgres;

--
-- Name: contact; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contact (
    contact_id integer NOT NULL,
    phone_number text,
    city_id integer NOT NULL
);


ALTER TABLE public.contact OWNER TO postgres;

--
-- Name: custom_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.custom_user (
    email text NOT NULL,
    password text NOT NULL,
    " total_id" integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.custom_user OWNER TO postgres;

--
-- Name: editor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.editor (
    contact_id integer NOT NULL,
    password text NOT NULL,
    email text NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.editor OWNER TO postgres;

--
-- Name: education; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.education (
    education_id integer NOT NULL,
    education_name text NOT NULL,
    education_point integer NOT NULL
);


ALTER TABLE public.education OWNER TO postgres;

--
-- Name: education_point; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.education_point (
    point_id integer NOT NULL,
    education_id integer NOT NULL
);


ALTER TABLE public.education_point OWNER TO postgres;

--
-- Name: exercise; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.exercise (
    exercise_name text,
    exercise_id integer NOT NULL,
    exercise_point integer
);


ALTER TABLE public.exercise OWNER TO postgres;

--
-- Name: exercise_point; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.exercise_point (
    point_id integer NOT NULL,
    exercise_id integer NOT NULL
);


ALTER TABLE public.exercise_point OWNER TO postgres;

--
-- Name: modarator; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.modarator (
    email text NOT NULL,
    password text NOT NULL,
    contact_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.modarator OWNER TO postgres;

--
-- Name: point; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.point (
    point_id integer NOT NULL,
    total_point integer
);


ALTER TABLE public.point OWNER TO postgres;

--
-- Name: quiz; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quiz (
    quiz_id integer NOT NULL,
    quiz_name text NOT NULL,
    quiz_point integer
);


ALTER TABLE public.quiz OWNER TO postgres;

--
-- Name: quiz_point; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quiz_point (
    point_id integer NOT NULL,
    quiz_id integer NOT NULL
);


ALTER TABLE public.quiz_point OWNER TO postgres;

--
-- Name: rozet; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rozet (
    rozet_id integer NOT NULL,
    rozet_name text NOT NULL,
    seviye text
);


ALTER TABLE public.rozet OWNER TO postgres;

--
-- Name: rozet_total; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rozet_total (
    total_id integer NOT NULL,
    rozet_id integer NOT NULL
);


ALTER TABLE public.rozet_total OWNER TO postgres;

--
-- Name: stars; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stars (
    stars_id integer NOT NULL,
    total_stars integer
);


ALTER TABLE public.stars OWNER TO postgres;

--
-- Name: total; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.total (
    total_id integer NOT NULL,
    point_id integer,
    stars_id integer NOT NULL
);


ALTER TABLE public.total OWNER TO postgres;

--
-- Name: user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."user" (
    name text NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public."user" OWNER TO postgres;

--
-- Name: user_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_user_id_seq OWNER TO postgres;

--
-- Name: user_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_user_id_seq OWNED BY public."user".user_id;


--
-- Name: user user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user" ALTER COLUMN user_id SET DEFAULT nextval('public.user_user_id_seq'::regclass);


--
-- Data for Name: admin; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.admin VALUES
	('emir@admin', 'admin', 1, 1),
	('eda@admin', 'admin', 2, 2);


--
-- Data for Name: city; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.city VALUES
	(34, 'istanbul'),
	(54, 'sakarya'),
	(37, 'kastamonu'),
	(1, 'adana'),
	(42, 'konya');


--
-- Data for Name: contact; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.contact VALUES
	(3, '0553 858 20 18', 1),
	(2, '0553 584 54 65', 34),
	(1, '0524 525 57 44', 54),
	(4, '5435', 34),
	(5, NULL, 34),
	(6, NULL, 34),
	(7, NULL, 34),
	(8, NULL, 34),
	(9, NULL, 34),
	(10, NULL, 34),
	(11, NULL, 34),
	(12, NULL, 34),
	(13, NULL, 34),
	(14, NULL, 34),
	(15, NULL, 34),
	(16, NULL, 34),
	(17, NULL, 34),
	(18, NULL, 34),
	(19, NULL, 34),
	(20, NULL, 34);


--
-- Data for Name: custom_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.custom_user VALUES
	('sevcan@custom', 'sevcan', 1, 3),
	('mehmet@custom', 'mehmet', 2, 4),
	('ezgi@custom', 'ezgi', 3, 5),
	('fatma@custom', 'fatma', 4, 6),
	('necla@custom', 'necla', 5, 7),
	('muhammed@custom', 'muhammed', 6, 8),
	('oguz@custom', 'oguz', 7, 9),
	('mami@custom', 'muhammed', 8, 10),
	('rahmi@custom', 'rahmi', 9, 11),
	('hüso@custom', 'hüso', 10, 12),
	('şule@custom', 'şule', 11, 13),
	('müberra@custom', 'müberra', 12, 14),
	('betüş@custom', 'betüş', 13, 15),
	('betül@custom', 'betül', 14, 16);


--
-- Data for Name: editor; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.editor VALUES
	(20, 'ramazan', 'ramazan@editor', 20);


--
-- Data for Name: education; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.education VALUES
	(1, 'c#', 20),
	(2, 'c++', 30),
	(3, 'java', 30),
	(4, 'html', 20);


--
-- Data for Name: education_point; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.education_point VALUES
	(1, 1),
	(1, 2),
	(2, 1),
	(3, 1),
	(4, 1),
	(5, 1),
	(6, 1),
	(7, 1),
	(8, 1),
	(9, 1),
	(10, 1),
	(11, 1),
	(12, 1),
	(13, 1),
	(14, 1);


--
-- Data for Name: exercise; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.exercise VALUES
	('c#', 1, 20),
	('c++', 2, 30),
	('java', 3, 40),
	('html', 4, 50);


--
-- Data for Name: exercise_point; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.exercise_point VALUES
	(1, 1),
	(2, 2),
	(3, 2),
	(3, 1),
	(3, 3),
	(4, 1),
	(5, 1),
	(6, 1),
	(7, 1),
	(8, 1),
	(9, 1),
	(10, 1),
	(11, 1),
	(12, 1),
	(13, 1),
	(14, 1);


--
-- Data for Name: modarator; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.modarator VALUES
	('berra', 'berra', 17, 17);


--
-- Data for Name: point; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.point VALUES
	(1, 400),
	(2, 100),
	(3, 100),
	(4, 100),
	(5, 10),
	(6, 100),
	(7, 100),
	(8, 100),
	(9, 200),
	(10, 100),
	(11, 100),
	(12, 100),
	(13, 100),
	(14, 100);


--
-- Data for Name: quiz; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.quiz VALUES
	(1, 'c#q1', 100),
	(2, 'c#q2', 200),
	(3, 'c++q1', 100),
	(4, 'c++q2', 200),
	(5, 'javaq1', 100),
	(6, 'javaq2', 200),
	(7, 'htmlq1', 100),
	(8, 'htmlq2', 200);


--
-- Data for Name: quiz_point; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.quiz_point VALUES
	(1, 1),
	(1, 2),
	(1, 3),
	(2, 1),
	(3, 1),
	(4, 1),
	(5, 1),
	(6, 1),
	(7, 2),
	(8, 3),
	(9, 4),
	(10, 1),
	(11, 1),
	(12, 1),
	(13, 3),
	(14, 1);


--
-- Data for Name: rozet; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.rozet VALUES
	(1, 'c#', 'başlangıc'),
	(2, 'c++', 'başlangıc'),
	(3, 'java', 'başlangıc'),
	(4, 'html', 'başlangıc'),
	(5, 'c#', 'orta'),
	(6, 'c++', 'orta'),
	(7, 'java', 'orta'),
	(8, 'html', 'orta'),
	(9, 'c#', 'ileri'),
	(10, 'c++', 'ileri'),
	(11, 'java', 'ileri'),
	(12, 'html', 'ileri');


--
-- Data for Name: rozet_total; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.rozet_total VALUES
	(1, 2),
	(1, 3),
	(1, 4),
	(2, 4),
	(3, 2),
	(4, 1);


--
-- Data for Name: stars; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.stars VALUES
	(1, 10),
	(2, 1),
	(3, 2),
	(4, 3),
	(5, 7),
	(6, 5),
	(7, 9),
	(8, 10),
	(9, 12),
	(10, 5),
	(11, 3),
	(12, 4),
	(13, 8),
	(14, 9);


--
-- Data for Name: total; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.total VALUES
	(2, 2, 2),
	(3, 3, 3),
	(4, 4, 4),
	(5, 5, 5),
	(6, 6, 6),
	(7, 7, 7),
	(8, 8, 8),
	(9, 9, 9),
	(10, 10, 10),
	(11, 11, 11),
	(12, 12, 12),
	(13, 13, 13),
	(14, 14, 14),
	(1, 1, 1);


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."user" VALUES
	('emir', 1),
	('sevcan', 3),
	('mehmet', 4),
	('fatma', 6),
	('necla', 7),
	('ezgi', 5),
	('eda', 2),
	('muhammed', 8),
	('oguz', 9),
	('mami', 10),
	('rahmi', 11),
	('hüso', 12),
	('melo', 13),
	('nazmi', 14),
	('betül', 15),
	('betüş', 16),
	('berra', 17),
	('müberra', 18),
	('şule', 19),
	('ramazan', 20);


--
-- Name: user_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_user_id_seq', 1, false);


--
-- Name: admin admin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin
    ADD CONSTRAINT admin_pkey PRIMARY KEY (user_id);


--
-- Name: city city_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.city
    ADD CONSTRAINT city_pkey PRIMARY KEY (city_id);


--
-- Name: contact contact_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact
    ADD CONSTRAINT contact_pkey PRIMARY KEY (contact_id);


--
-- Name: custom_user custom_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_user
    ADD CONSTRAINT custom_user_pkey PRIMARY KEY (user_id);


--
-- Name: editor editor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.editor
    ADD CONSTRAINT editor_pkey PRIMARY KEY (user_id);


--
-- Name: exercise_point exercise_point_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exercise_point
    ADD CONSTRAINT exercise_point_pkey PRIMARY KEY (point_id, exercise_id);


--
-- Name: modarator modarator_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modarator
    ADD CONSTRAINT modarator_pkey PRIMARY KEY (user_id);


--
-- Name: quiz quiz_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz
    ADD CONSTRAINT quiz_pkey PRIMARY KEY (quiz_id);


--
-- Name: rozet rozet_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rozet
    ADD CONSTRAINT rozet_pkey PRIMARY KEY (rozet_id);


--
-- Name: rozet_total rozet_total_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rozet_total
    ADD CONSTRAINT rozet_total_pkey PRIMARY KEY (total_id, rozet_id);


--
-- Name: admin unique_admin_contact_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin
    ADD CONSTRAINT unique_admin_contact_id UNIQUE (contact_id);


--
-- Name: admin unique_admin_email1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin
    ADD CONSTRAINT unique_admin_email1 UNIQUE (email);


--
-- Name: city unique_city_city_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.city
    ADD CONSTRAINT unique_city_city_id UNIQUE (city_id);


--
-- Name: custom_user unique_custom_user_email; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_user
    ADD CONSTRAINT unique_custom_user_email UNIQUE (email);


--
-- Name: custom_user unique_custom_user_toplevel_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_user
    ADD CONSTRAINT unique_custom_user_toplevel_id UNIQUE (" total_id");


--
-- Name: editor unique_editor_email; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.editor
    ADD CONSTRAINT unique_editor_email UNIQUE (email);


--
-- Name: editor unique_editor_toplevel_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.editor
    ADD CONSTRAINT unique_editor_toplevel_id UNIQUE (contact_id);


--
-- Name: education unique_education_education_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.education
    ADD CONSTRAINT unique_education_education_id PRIMARY KEY (education_id);


--
-- Name: exercise unique_exercise_id_exercise_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exercise
    ADD CONSTRAINT unique_exercise_id_exercise_id PRIMARY KEY (exercise_id);


--
-- Name: modarator unique_modarator_email; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modarator
    ADD CONSTRAINT unique_modarator_email UNIQUE (email);


--
-- Name: modarator unique_modarator_toplevel_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modarator
    ADD CONSTRAINT unique_modarator_toplevel_id UNIQUE (contact_id);


--
-- Name: point unique_point_point_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.point
    ADD CONSTRAINT unique_point_point_id PRIMARY KEY (point_id);


--
-- Name: quiz unique_quiz_quiz_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz
    ADD CONSTRAINT unique_quiz_quiz_id UNIQUE (quiz_id);


--
-- Name: stars unique_stas_stars_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stars
    ADD CONSTRAINT unique_stas_stars_id PRIMARY KEY (stars_id);


--
-- Name: total unique_total_point_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.total
    ADD CONSTRAINT unique_total_point_id UNIQUE (point_id);


--
-- Name: total unique_total_stars_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.total
    ADD CONSTRAINT unique_total_stars_id UNIQUE (stars_id);


--
-- Name: total unique_total_total_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.total
    ADD CONSTRAINT unique_total_total_id PRIMARY KEY (total_id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (user_id);


--
-- Name: index_exercise_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_exercise_id ON public.exercise USING btree (exercise_id);


--
-- Name: index_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_name ON public."user" USING btree (name);


--
-- Name: contact city_contact; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact
    ADD CONSTRAINT city_contact FOREIGN KEY (city_id) REFERENCES public.city(city_id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: admin contact_admin; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin
    ADD CONSTRAINT contact_admin FOREIGN KEY (contact_id) REFERENCES public.contact(contact_id) MATCH FULL;


--
-- Name: editor contact_editor; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.editor
    ADD CONSTRAINT contact_editor FOREIGN KEY (contact_id) REFERENCES public.contact(contact_id) MATCH FULL;


--
-- Name: modarator contact_modarator; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modarator
    ADD CONSTRAINT contact_modarator FOREIGN KEY (contact_id) REFERENCES public.contact(contact_id) MATCH FULL;


--
-- Name: education_point education_education_point; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.education_point
    ADD CONSTRAINT education_education_point FOREIGN KEY (education_id) REFERENCES public.education(education_id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: exercise_point exercise_exercisepoint; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exercise_point
    ADD CONSTRAINT exercise_exercisepoint FOREIGN KEY (exercise_id) REFERENCES public.exercise(exercise_id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: education_point point_educationpoint; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.education_point
    ADD CONSTRAINT point_educationpoint FOREIGN KEY (point_id) REFERENCES public.point(point_id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: exercise_point point_exercisepoint; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exercise_point
    ADD CONSTRAINT point_exercisepoint FOREIGN KEY (point_id) REFERENCES public.point(point_id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: quiz_point point_quizpoint; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_point
    ADD CONSTRAINT point_quizpoint FOREIGN KEY (point_id) REFERENCES public.point(point_id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: quiz_point quiz_quiz_point; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_point
    ADD CONSTRAINT quiz_quiz_point FOREIGN KEY (quiz_id) REFERENCES public.quiz(quiz_id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rozet_total rozet_rozettotal; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rozet_total
    ADD CONSTRAINT rozet_rozettotal FOREIGN KEY (rozet_id) REFERENCES public.rozet(rozet_id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: custom_user total_customuser; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_user
    ADD CONSTRAINT total_customuser FOREIGN KEY (" total_id") REFERENCES public.total(total_id) MATCH FULL ON DELETE CASCADE;


--
-- Name: total total_point; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.total
    ADD CONSTRAINT total_point FOREIGN KEY (point_id) REFERENCES public.point(point_id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rozet_total total_rozettotal; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rozet_total
    ADD CONSTRAINT total_rozettotal FOREIGN KEY (total_id) REFERENCES public.total(total_id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: total total_stars; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.total
    ADD CONSTRAINT total_stars FOREIGN KEY (stars_id) REFERENCES public.stars(stars_id) MATCH FULL;


--
-- Name: admin user_admin; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin
    ADD CONSTRAINT user_admin FOREIGN KEY (user_id) REFERENCES public."user"(user_id) MATCH FULL ON DELETE CASCADE;


--
-- Name: custom_user user_customuser; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_user
    ADD CONSTRAINT user_customuser FOREIGN KEY (user_id) REFERENCES public."user"(user_id) MATCH FULL ON DELETE CASCADE;


--
-- Name: editor user_editor; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.editor
    ADD CONSTRAINT user_editor FOREIGN KEY (user_id) REFERENCES public."user"(user_id) MATCH FULL ON DELETE CASCADE;


--
-- Name: modarator user_modarator; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modarator
    ADD CONSTRAINT user_modarator FOREIGN KEY (user_id) REFERENCES public."user"(user_id) MATCH FULL ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

