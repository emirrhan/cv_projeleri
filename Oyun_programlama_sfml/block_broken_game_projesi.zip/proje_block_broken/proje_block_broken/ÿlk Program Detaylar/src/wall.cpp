#include "../include/wall.hpp"

Wall::Wall( Sprite s, int wallTextureID ) : Element( s ) {
    textureID = wallTextureID;
}
