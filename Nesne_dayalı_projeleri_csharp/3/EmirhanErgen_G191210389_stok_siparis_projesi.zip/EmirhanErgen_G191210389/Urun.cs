﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmirhanErgen_G191210389
{
    public abstract class Urun //Her ürün bu sınıftan miras alıcak
    {
        public static readonly Random rnd = new Random();
        public static readonly Object randomcu = new Object();
        public abstract int KdvUygula(int a);
        string Ad;
        public string ad
        {
            get { return Ad; }
            set { Ad = value; }
        }

        internal static double KdvUygula(Urun x)
        {
            throw new NotImplementedException();
        }

        string Marka;
        public string marka
        {
            get { return Marka; }
            set { Marka = value; }
        }
        int Model;
        public int model
        {
            get { return Model; }
            set { Model = value; }
        }
        string Ozellik;
        public string ozellik
        {
            get { return Ozellik; }
            set { Ozellik = value; }
        }
        int StokAdedi;
        public int stokAdedi
        {
            get { return StokAdedi; }
            set { StokAdedi = value; }
        }
        int HamFiyat;
        public int hamFiyat
        {
            get { return HamFiyat; }
            set { HamFiyat = value; }
        }
        int SecilenAdet;
        public int secilenAdet
        {
            get { return SecilenAdet; }
            set { SecilenAdet = value; }
        }




    }
}
