﻿/*
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2014-2015 BAHAR DÖNEMİ
**	
**				ÖĞRENCİ ADI............:EmirhanERGEN
**				ÖĞRENCİ NUMARASI.......:G191210389
**              DERSİN ALINDIĞI GRUP...:2. Öğretim C
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmirhanERGEN_G191210389_PRJ
{
    public class KagitAtikKutusu:AtikKutusu
    {
        public KagitAtikKutusu(int bosaltmaPuani, int kapasite, int doluHacim, int dolulukOrani)
        {
            this.BosaltmaPuani = bosaltmaPuani;
            this.Kapasite = kapasite;
            this.DoluHacim = doluHacim;
            this.DolulukOrani = dolulukOrani;
        }
    }
}
