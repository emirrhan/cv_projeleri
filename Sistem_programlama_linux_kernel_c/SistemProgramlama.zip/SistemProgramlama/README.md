Onur KAHVECİ-B201210500-2B Grubu
Furkan AKSOY-G201210510-1B Grubu
Mehtap KARTAL-G191210504-1B Grubu
Emirhan ERGEN-G191210389-2B Grubu

 Program derlenme aşaması adım adım gerçekleştirildi.İlk olarak .kilit doyası verileri çekilip ekrana basıldı.Daha sonra .kilit dosyasında ki format (kelime,kod) şeklinde
 parçalandı . Bir sonraki adım ise ağaca yüklemem oldu. Bunları yaparken CS360 sitesindeki örneklerden yararlanıldı. Ağaca eklemenin her satırı denendi ve ekranda çıkan sonucun doğruluğu jrb_traverse fonksiyonu kullanılarak teeyit edildi. Daha sonra arama işlemi için JRB kütüphanesinin  jrb_find_str() fonksiyonu kullanılmıştır. İlk olarak tek terim ile denemeler yapıldı geri dönüş doğru olduğu görüşünce örnek metin ile denemeler yapıldı ve ekrana yazma işlemi ile sonuç görüldü. Ardından istenilen giriş şekli paramterte ayarları ile yapıldı. -e ve -d kontrolu ardından hata kontrolleri yapıldı ve dosya olmadığı taktirde hata vermesi sağlandı. Son aşama ise çıkış dosyasının elde edilmesi olmuştur. Bunun için se fprinf() fonksiyonu kullanılmıştır
