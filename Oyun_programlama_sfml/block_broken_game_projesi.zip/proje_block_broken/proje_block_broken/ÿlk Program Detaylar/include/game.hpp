#ifndef _GAME_HPP__
#define _GAME_HPP__

#include "textures.hpp"
#include "game_elements.hpp"
#include <SFML/Graphics.hpp>
#include <string>
#include <vector>
#include <iostream>

using namespace sf;
using namespace std;

#define WINDOW_COORDINATE_X         (595)
#define WINDOW_COORDINATE_Y         (980)

class Game {
public:
  // attrs

  Texture backgroundTexture;

  const String brickSkins[6] = {
      "./Dependencies/bin/resimler/Bricks/brick_blue_small.png",  // Blue Brick
      "./Dependencies/bin/resimler/Bricks/brick_green_small.png", // Green Brick
      "./Dependencies/bin/resimler/Bricks/brick_pink_small.png",  // Pink Brick
      "./Dependencies/bin/resimler/Bricks/brick_violet_small.png", // Violet
      "./Dependencies/bin/resimler/Bricks/brick_yellow_small.png", // Yellow
      "./Dependencies/bin/resimler/Bricks/brick_yellow_small.png"  // Yellow
  };

  const String wallSkins[6] = {
      "./Dependencies/bin/resimler/Walls/brick.png",           // Normal Wall
      "./Dependencies/bin/resimler/Walls/brick_blue.png",      // Blue Wall
      "./Dependencies/bin/resimler/Walls/brick_pink_side.png", // Pink Wall
      "./Dependencies/bin/resimler/Walls/brick_red.png",       // Red Wall
      "./Dependencies/bin/resimler/Walls/brick_pink_side.png", // Pink Wall
      "./Dependencies/bin/resimler/Walls/brick_red.png"        // Red Wall
  };

  const String ballSkins[6] = {
      "./Dependencies/bin/resimler/Balls/ball_blue.png",   // Blue Ball
      "./Dependencies/bin/resimler/Balls/ball_green.png",  // Green Ball
      "./Dependencies/bin/resimler/Balls/ball_orange.png", // Orange Ball
      "./Dependencies/bin/resimler/Balls/ball_red.png",    // Red Ball
      "./Dependencies/bin/resimler/Balls/ball_silver.png", // Silver Ball
      "./Dependencies/bin/resimler/Balls/ball_yellow.png"  // Yellow Ball
      };

  const String playerSkins[6] = {
      "./Dependencies/bin/resimler/Bats/bat_black.png",
      "./Dependencies/bin/resimler/Bats/bat_blue.png",
      "./Dependencies/bin/resimler/Bats/bat_orange.png",
      "./Dependencies/bin/resimler/Bats/bat_pink.png",
      "./Dependencies/bin/resimler/Bats/bat_yellow.png",
      "./Dependencies/bin/resimler/Bats/bat_yellow.png"};

    Texture brickTextures[6];
    Texture wallTextures[6];
    Texture ballTextures[6];
    Texture playerTextures[6];

  // essential game elements
  Background *background;
  Player *player;
  Ball *ball;
  vector< Brick > bricks;
  vector< Wall > walls;

  String name;
  Event event; // main event

  // TODO: game.hpp attributes Texture replace with normal classes. since they already have skin attributes
  RenderWindow *window;
  uint16_t windowDimentionX;
  uint16_t windowDimentionY;

  // methods
  Game(String name, uint16_t dimX, uint16_t dimY); // ctor
  void init(void);

  // TODO: brake down this class to smaller ones
  bool recievedClose(Event event);
  void close(void);
  void clearScreen(void);
  void refreshScreen(void);
  
  void setTextures();

  void generatePlayer();
  void generateBall();
  void generateWall();
  void generateBackground();
  void generateBricks();

  void drawWall();
  void drawBricks();
  void drawElements();

  void handleInput();

  bool isCollide( Element p, Element b );
  bool isIntersect( Element e, int x, int y);
  void handleCollisions();

  pair<Texture*, int> getRandomTexture( Texture* textures);
};

#endif // _GAME_HPP__
