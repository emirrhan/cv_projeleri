﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmirhanErgen_G191210389
{
    public class Laptop : Urun
    {
        string DahiliHafiza;
        public string dahiliHafiza
        {
            get { return DahiliHafiza; }
            set { DahiliHafiza = value; }
        }
        string RamKapasitesi;
        public string ramKapasitesi
        {
            get { return RamKapasitesi; }
            set { RamKapasitesi = value; }
        }
        string PilGucu;
        public string pilGucu
        {
            get { return PilGucu; }
            set { PilGucu = value; }
        }
        string EkranCozunurluk;
        public string ekranCozunurluk
        {
            get { return EkranCozunurluk; }
            set { EkranCozunurluk = value; }
        }
        string EkranBoyutu;
        public string ekranBoyutu
        {
            get { return EkranBoyutu; }
            set { EkranBoyutu = value; }
        }

        public Laptop()
        {

            lock (randomcu)
            {
                stokAdedi = rnd.Next(1, 100);
            }
            ad = "MSI GAMING";
            hamFiyat = 6548;
            dahiliHafiza = "1TB + 256GB SSD";
            ekranCozunurluk = "2k";
            ekranBoyutu = "17.3 FHD";
            marka = "GAMING X PLUS";
            pilGucu = "6500Mha";
            ramKapasitesi = "16GB";
            secilenAdet = 1;



        }
        public override int KdvUygula(int a)
        {
            a = (hamFiyat + (hamFiyat * 15) / 100) * secilenAdet;

            return a;
        }


    }
}
