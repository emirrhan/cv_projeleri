#include <SFML/Graphics.hpp>
#include <iostream>
#include <stdint.h>
#include "../include/game.hpp"
#include "../include/game_elements.hpp"
#include "../include/textures.hpp"

int main(void) {
  srand(time(0));
  
  Game breakout = Game("Breakout! ",
                       WINDOW_COORDINATE_X,
                       WINDOW_COORDINATE_Y );
  breakout.init();

  while (breakout.window->isOpen()) {
    Event event;
    while (breakout.window->pollEvent(event)) {
      if (breakout.recievedClose(event))
        breakout.close();
    }
    breakout.clearScreen();


    // breakout.ball.getPosition()

    breakout.handleInput();

    // Drawing
     breakout.drawElements();
    
    // breakout.handleBallPlayerCollision();
    breakout.handleCollisions();
    breakout.refreshScreen();
  }
  return EXIT_SUCCESS;
}
