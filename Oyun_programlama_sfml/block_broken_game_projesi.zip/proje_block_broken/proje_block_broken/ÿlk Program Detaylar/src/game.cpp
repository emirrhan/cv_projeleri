#include "../include/game.hpp"

Game::Game(String name, uint16_t dimX, uint16_t dimY) {
  this->windowDimentionX = dimX;
  this->windowDimentionY = dimY;
  this->name = name;
}

void Game::refreshScreen(void) { this->window->display(); }
void Game::clearScreen(void) { this->window->clear(); }
void Game::close(void) { this->window->close(); }
bool Game::recievedClose(Event event) { return (event.type == Event::Closed); }
void Game::init(void) {

  // Create the main window
  this->window = new RenderWindow(
      VideoMode(this->windowDimentionX, this->windowDimentionY), this->name);

  this->window->setFramerateLimit(60);

  setTextures();
  backgroundTexture.loadFromFile("./Dependencies/bin/resimler/Background/background.jpg");

  // generate elements
  generateWall();
  generateBricks();
  generatePlayer();
  generateBall();
  generateBackground();
}

void Game::generateWall() {
  for (int i = 0; i < NUMBER_OF_WALLBRICKS_X; i++) {
    pair<Texture*, int> randomTexture = getRandomTexture( wallTextures );
    Sprite s(*randomTexture.first);
    Vector2f vec(0.25, 0.25);
    s.setScale(vec);
    s.setPosition(i*(DISTANCE_BETWEEN_WALLBRICKS), 0);
    walls.push_back(Wall( s, randomTexture.second ));
  }
  for (int i = 0; i < NUMBER_OF_WALLBRICKS_X; i++) {
    pair<Texture*, int> randomTexture = getRandomTexture( wallTextures );
    Sprite s(*randomTexture.first);
    Vector2f vec(0.25, 0.25);
    s.setScale(vec);
    s.setPosition(i*(DISTANCE_BETWEEN_WALLBRICKS), 945);
    walls.push_back(Wall( s, randomTexture.second));
  }
  for (int i = 0; i < NUMBER_OF_WALLBRICKS_Y; i++) {
    pair<Texture*, int> randomTexture = getRandomTexture( wallTextures );
    Sprite s(*randomTexture.first);
    Vector2f vec(0.25, 0.25);
    s.setScale(vec);
    s.setPosition(0, i*(DISTANCE_BETWEEN_WALLBRICKS)+35);
    walls.push_back(
        Wall( s, randomTexture.second));
  }
  for (int i = 0; i < NUMBER_OF_WALLBRICKS_Y; i++) {
    pair<Texture*, int> randomTexture = getRandomTexture( wallTextures );
    Sprite s(*randomTexture.first);
    Vector2f vec(0.25, 0.25);
    s.setScale(vec);
    s.setPosition(560, i*(DISTANCE_BETWEEN_WALLBRICKS)+35);
    walls.push_back(
        Wall( s, randomTexture.second));
  }
}

void Game::drawWall() {
  int numberOfWallBricks = 2 * (NUMBER_OF_WALLBRICKS_X + NUMBER_OF_WALLBRICKS_Y);
  for (int i = 0; i < numberOfWallBricks; i++) {
    this->window->draw(walls[i].getSprite());
  }
}

void Game::generateBricks() {
  int distancePerRow = BRICK_CHUNK_STARTING_Y;
  for (int j = 0; j < NUMBER_OF_BRICK_ROWS; j++) {
    for (int i = 0; i < BRICKS_PER_ROW; i++) {
      pair<Texture*, int> randomTexture = getRandomTexture( brickTextures );

      Sprite s(*randomTexture.first);
      Vector2f vec(0.5, 0.5);
      s.setScale(vec);
      s.setPosition((i*80)+62, j*50+70);

      bricks.push_back(Brick( s, randomTexture.second ));
    }
    distancePerRow += BRICK_CHUNK_STARTING_Y;
  }
}

void Game::drawBricks() {
  for (int i = 0; i < TOTAL_BRICKS; i++) {
    this->window->draw(bricks[i].getSprite());
  }
}

void Game::handleInput() {
  if (sf::Keyboard::isKeyPressed( Keyboard::Space ) ) {
    ball->isMoving = true;
  }

  if (sf::Keyboard::isKeyPressed( Keyboard::Left ) || sf::Keyboard::isKeyPressed( Keyboard::H ) ) {
    if ( player->getPosition().x > DISTANCE_BETWEEN_WALLBRICKS ) {
      player->move(-10, 0);
      if (!ball->isMoving)
        ball->move(-10, 0);
    }
  }

  if (sf::Keyboard::isKeyPressed( Keyboard::Right )|| sf::Keyboard::isKeyPressed( Keyboard::L)) {
    if ( player->getPosition().x < 455 ) {
      player->move(10, 0);
      if (!ball->isMoving)
        ball->move(10, 0);
    }
  }
}
void Game::generatePlayer() {
  pair<Texture*, int> p = getRandomTexture(playerTextures);
  Sprite sprite( *p.first );
  Vector2f vec(0.5, 0.5);
  sprite.setScale(vec);
  sprite.setPosition(245, 910);
  player = new Player( sprite, p.second );
}
void Game::generateBall() {
  pair<Texture*, int> p = getRandomTexture(ballTextures);
  Sprite sprite( *p.first );
  Vector2f vec(0.06, 0.06);
  sprite.setScale(vec);
  sprite.setPosition(286,886);
  ball = new Ball( sprite, p.second );
}

bool Game::isCollide( Element e1, Element e2 ) {
  return e1.getGlobalBounds().intersects(e2.getGlobalBounds());
}

void Game::handleCollisions() {
    if (!ball->isMoving)
      return;
    
    Vector2f ballPosition = ball->getPosition();
    if (ballPosition.x <= 35 || ballPosition.x >= 538)
      ball->directionX *= -1;
    if (ballPosition.y <= 35 || ballPosition.y >= 923)
      ball->directionY *= -1;

    ball->move(ball->directionX, 0);
    for ( int i = 0; i < 36; i++  ) {
      if (isCollide(bricks[i], *ball)) {
        bricks[i].switchState();
        ball->directionX *= -1;
        Vector2f pos = ball->getPosition();
        ball->setPosition(pos.x+ball->directionX, pos.y);
      }
    }
    ball->move(0, ball->directionY);
    for ( int i = 0; i < 36; i++  ) {
      if (isCollide(bricks[i], *ball)) {
        bricks[i].switchState();
        ball->directionY *= -1;
        Vector2f pos = ball->getPosition();
        ball->setPosition(pos.x, pos.y+ball->directionY);
      }
    }
    if (isCollide(*player, *ball))
      ball->directionY = -(rand()%3+1);
}

pair<Texture*, int> Game::getRandomTexture( Texture* textures) {
  int index = rand() % 6;
  pair<Texture*, int> p;
  p.first = &textures[index];
  p.second = index;
  return p;
}

void Game::drawElements() {
 this->window->draw(background->getSprite());
 drawWall();
 drawBricks();
 this->window->draw(player->getSprite());
 this->window->draw(ball->getSprite());
}

void Game::generateBackground() {
  Sprite s(backgroundTexture);
  background = new Background(s);
}

void Game::setTextures() {
  for (int i = 0; i < 6; i++) {
    brickTextures[i].loadFromFile(brickSkins[i]);
  }
  for (int i = 0; i < 6; i++) {
    wallTextures[i].loadFromFile(wallSkins[i]);
  }
  for (int i = 0; i < 6; i++) {
    ballTextures[i].loadFromFile(ballSkins[i]);
  }
  for (int i = 0; i < 6; i++) {
    playerTextures[i].loadFromFile(playerSkins[i]);
  }
}