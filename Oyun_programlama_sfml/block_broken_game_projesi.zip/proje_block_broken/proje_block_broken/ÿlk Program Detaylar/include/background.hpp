#ifndef _BACKGROUND_HPP_
#define _BACKGROUND_HPP_

#include "Element.hpp"

class Background : public Element {
public:
    Background( Sprite s );
};

#endif
