﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmirhanErgen_G191210389
{
    public partial class Form1 : Form
    {
        Buzdolabı buz;
        LedTv tv;
        CepTel tel;
        Laptop lap;
        Sepet spt;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            spt = new Sepet();
            buz = new Buzdolabı();
            tv = new LedTv();
            tel = new CepTel();
            lap = new Laptop();

            dolap_fiyat_label.Text = buz.hamFiyat.ToString();
            laptop_fiyat_label.Text = lap.hamFiyat.ToString();
            tv_fiyat_label.Text = tv.hamFiyat.ToString();
            tel_fiyat_label.Text = tel.hamFiyat.ToString();

            dolap_stok_label.Text = buz.stokAdedi.ToString();
            laptop_stok_label.Text = lap.stokAdedi.ToString();
            tv_stok_label.Text = tv.stokAdedi.ToString();
            tel_stok_label.Text = tel.stokAdedi.ToString();
        }

        private void sepete_ekle_Click(object sender, EventArgs e)
        {
            int toplam_miktar = 0;

            buz.secilenAdet = Convert.ToInt32(dolap_adet.Value);
            tv.secilenAdet = Convert.ToInt32(tv_adet.Value);
            lap.secilenAdet = Convert.ToInt32(laptop_adet.Value);
            tel.secilenAdet = Convert.ToInt32(tel_adet.Value);

            int buz_degişken = buz.KdvUygula(Convert.ToInt32(dolap_adet.Value));
            int lap_degişken = lap.KdvUygula(Convert.ToInt32(laptop_adet.Value));
            int tel_degişken = tel.KdvUygula(Convert.ToInt32(tel_adet.Value));
            int tv_degişken = tv.KdvUygula(Convert.ToInt32(tv_adet.Value));

            if (adet_list.Items.Count > 0)
            {
                MessageBox.Show("Sepeti Temizlemeden Yeni Ürün Ekleyemezsiniz!");
            }
            else
            {
                if (dolap_adet.Value == 0 && laptop_adet.Value == 0 && tel_adet.Value == 0 && tv_adet.Value == 0)
                {
                    MessageBox.Show("Ürün Seçimi Yapınız ...!");
                }
                if (Convert.ToInt32(dolap_stok_label.Text) != 0)
                {
                    if (Convert.ToInt32(dolap_adet.Value) > 0)
                    {
                        adet_list.Items.Add(Convert.ToInt32(dolap_adet.Value));
                        ürün_list.Items.Add("Buz Dolabı");
                        kdv_list.Items.Add(buz_degişken);
                        dolap_stok_label.Text = (Convert.ToInt32(dolap_stok_label.Text) - (Convert.ToInt32(dolap_adet.Value))).ToString();

                    }

                    if (Convert.ToInt32(laptop_stok_label.Text) != 0)
                    {
                        if (Convert.ToInt32(laptop_adet.Value) > 0)
                        {
                            adet_list.Items.Add(Convert.ToInt32(laptop_adet.Value));
                            ürün_list.Items.Add("Laptop");
                            kdv_list.Items.Add(lap_degişken);
                            laptop_stok_label.Text = (Convert.ToInt32(laptop_stok_label.Text) - (Convert.ToInt32(laptop_adet.Value))).ToString();

                        }
                    }

                    if (Convert.ToInt32(tv_stok_label.Text) != 0)
                    {
                        if (Convert.ToInt32(tv_adet.Value) > 0)
                        {
                            adet_list.Items.Add(Convert.ToInt32(tv_adet.Value));
                            ürün_list.Items.Add("LCD TELEVİZYON");
                            kdv_list.Items.Add(tv_degişken);
                            tv_stok_label.Text = (Convert.ToInt32(tv_stok_label.Text) - (Convert.ToInt32(tv_adet.Value))).ToString();
                        }
                    }

                    if (Convert.ToInt32(tel_stok_label.Text) != 0)
                    {
                        if (Convert.ToInt32(tel_adet.Value) > 0)
                        {
                            adet_list.Items.Add(Convert.ToInt32(tel_adet.Value));
                            ürün_list.Items.Add("Cep Telefonu");
                            kdv_list.Items.Add(tel_degişken);
                            tel_stok_label.Text = (Convert.ToInt32(tel_stok_label.Text) - (Convert.ToInt32(tel_adet.Value))).ToString();
                        }
                       
                    }
                    if (Convert.ToInt32(tel_stok_label.Text) < 0)
                    {
                        tel_stok_label.Text = "0";
                        kdv_list.Items.Clear();
                        adet_list.Items.Clear();
                        ürün_list.Items.Clear();
                        MessageBox.Show("İstediğiniz Adette Telefon Stokta kalmamıştır Lütfen Stok Adetlerine Dikkat ediniz :)");
                        
                    }
                    if (Convert.ToInt32(dolap_stok_label.Text) < 0)
                    {
                        dolap_stok_label.Text = "0";
                        kdv_list.Items.Clear();
                        adet_list.Items.Clear();
                        ürün_list.Items.Clear();
                        MessageBox.Show("İstediğiniz Adette Buz Dolabı Stokta kalmamıştır Lütfen Stok Adetlerine Dikkat ediniz :)");
                        
                    }
                    if (Convert.ToInt32(laptop_stok_label.Text) < 0)
                    {
                        laptop_stok_label.Text = "0";
                        kdv_list.Items.Clear();
                        adet_list.Items.Clear();
                        ürün_list.Items.Clear();
                        MessageBox.Show("İstediğiniz Adette Laptop Stokta kalmamıştır Lütfen Stok Adetlerine Dikkat ediniz :)");
                        
                    }
                    if (Convert.ToInt32(tv_stok_label.Text) < 0)
                    {
                        tv_stok_label.Text = "0";
                        kdv_list.Items.Clear();
                        adet_list.Items.Clear();
                        ürün_list.Items.Clear();
                        MessageBox.Show("İstediğiniz Adette Tv Stokta kalmamıştır Lütfen Stok Adetlerine Dikkat ediniz :)");
                        
                    }



                    for (int i = 0; i < adet_list.Items.Count; i++)
                    {
                        toplam_miktar = toplam_miktar + Convert.ToInt32(kdv_list.Items[i]);
                    }
                    toplam_fiyat.Text = toplam_miktar.ToString() + " TL";
                   
                }
            }
        }

        private void sepeti_temizle_Click_1(object sender, EventArgs e)
        {
            if (kdv_list.Items.Count == 0 && adet_list.Items.Count == 0 && ürün_list.Items.Count == 0)
            {
                MessageBox.Show("Sepetiniz zaten boş");
            }
            else
            {
                kdv_list.Items.Clear();
                ürün_list.Items.Clear();
                adet_list.Items.Clear();
                toplam_fiyat.Text = "";

                dolap_stok_label.Text = (Convert.ToInt32(dolap_stok_label.Text) + (Convert.ToInt32(dolap_adet.Value))).ToString();
                laptop_stok_label.Text = (Convert.ToInt32(laptop_stok_label.Text) + (Convert.ToInt32(laptop_adet.Value))).ToString();
                tv_stok_label.Text = (Convert.ToInt32(tv_stok_label.Text) + (Convert.ToInt32(tv_adet.Value))).ToString();
                tel_stok_label.Text = (Convert.ToInt32(tel_stok_label.Text) + (Convert.ToInt32(tel_adet.Value))).ToString();

                tv_adet.Value = 0;
                dolap_adet.Value = 0;
                laptop_adet.Value = 0;
                tel_adet.Value = 0;
            }
        }
    }
}
