﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmirhanErgen_G191210389
{
    public class Sepet
    {
        
      public List<Urun> SecilenlerListesi = new List<Urun>();
      public double total_kdv { get; set; }
        public void SepeteUrunEkle(Urun x)
        {
            total_kdv += Urun.KdvUygula(x);
            SecilenlerListesi.Add(x);
        }




    }
}
