﻿/*
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2014-2015 BAHAR DÖNEMİ
**	
**				ÖĞRENCİ ADI............:EmirhanERGEN
**				ÖĞRENCİ NUMARASI.......:G191210389
**              DERSİN ALINDIĞI GRUP...:2. Öğretim C
*/
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmirhanERGEN_G191210389_PRJ
{
    public class Gazete:Atik
    {
        public Gazete(int hacim, Image image, string atikAdi, string atikCinsi)
        {
            this.Hacim = hacim;
            this.Image = image;
            this.AtikAdi = atikAdi;
            this.AtikCinsi = atikCinsi;
        }
    }
}
