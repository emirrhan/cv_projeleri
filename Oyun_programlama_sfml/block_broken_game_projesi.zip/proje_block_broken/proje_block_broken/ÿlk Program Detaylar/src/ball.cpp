#include "../include/ball.hpp"
#include <iostream> // FIXME: delete this line
using namespace std;// FIXME: delete this line

// FIXME: these first defined in game.hpp. fix this
#define WINDOW_COORDINATE_X         (600)
#define WINDOW_COORDINATE_Y         (1020)
#define DISTANCE_BETWEEN_WALLBRICKS (35) // px
#define DEFAULT_MOVEMENT_SPEED      (1)

Ball::Ball( Sprite s, int ballTextureID ) : DynamicElement( s ) {
    isMoving = false;
    textureID = ballTextureID;
}