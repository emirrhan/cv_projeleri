#ifndef _WALL_HPP__
#define _WALL_HPP__

#define DISTANCE_BETWEEN_WALLBRICKS (35) // px
#define NUMBER_OF_WALLBRICKS_X      (17)
#define NUMBER_OF_WALLBRICKS_Y      (26)

#include "Element.hpp"

class Wall : public Element {
        // members
        public:
          int textureID;
        // methods
    Wall( Sprite s, int wallTextureID );
};

#endif // _WALL_HPP__
