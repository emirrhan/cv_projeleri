﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Emirhan_Ergen_G191210389
{
    /****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2014-2015 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI..........:2
**				ÖĞRENCİ ADI............:Emirhan Ergen
**				ÖĞRENCİ NUMARASI.......:g191210389
**                         DERSİN ALINDIĞI GRUP...:2. Öğretim C grubu
****************************************************************************/

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public ListBox listBox1 { get; private set; }
        public ListBox listBox2 { get; private set; }
        public TextBox textBox3 { get; private set; }
        public TextBox textBox4 { get; private set; }
        public TextBox textBox5 { get; private set; }
        public int butonabasildimi = 0;
       
        private void button1_Click(object sender, EventArgs e)
        {
            
            
            if (butonabasildimi==0)
            {
                Label label3 = new Label();
                label3.Text = "SONUC :";
                label3.Name = "label3";
                label3.Size = new Size(55, 13);
                label3.Location = new Point(50, 164);
                Controls.Add(label3);
                //***********************************
                Label label4 = new Label();
                label4.Text = "X DEĞERLERİ";
                label4.Name = "label4";
                label4.Size = new Size(100, 20);
                label4.Location = new Point(270, 13);
                Controls.Add(label4);
                Label label5 = new Label();
                label5.Text = "Y DEĞERİ";
                label5.Name = "label5";
                label5.Size = new Size(100, 20);
                label5.Location = new Point(420, 13);
                Controls.Add(label5);
                //************************************
                Label label6 = new Label();
                label6.Text = "TOPLAMLAR :";
                label6.Name = "label6";
                label6.Size = new Size(80, 20);
                label6.Location = new Point(180, 220);
                Controls.Add(label6);
                //************************************
                 listBox1 = new ListBox();
                listBox1.Name = "listBox1";
                listBox1.Size = new Size(120, 173);
                listBox1.Location = new Point(260, 36);
                Controls.Add(listBox1);
                listBox2 = new ListBox();
                listBox2.Name = "listBox2";
                listBox2.Size = new Size(120, 173);
                listBox2.Location = new Point(402, 36);
                Controls.Add(listBox2);
                //**********SONUC KISMI****************
                 textBox3 = new TextBox();
                textBox3.Name = "textBox3";
                textBox3.Size = new Size(130, 34);
                textBox3.Location = new Point(105, 162);
                Controls.Add(textBox3);
                //************************************
                textBox4= new TextBox();
                textBox4.Name = "textBox4";
                textBox4.Size = new Size(120, 20);
                textBox4.Location = new Point(260, 217);
                Controls.Add(textBox4);
                textBox5 = new TextBox();
                textBox5.Name = "textBox5";
                textBox5.Size = new Size(120, 20);
                textBox5.Location = new Point(402, 217);
                Controls.Add(textBox5);

            }
            butonabasildimi = 1;

            //************************************
            //DEGİŞKEN TANIMLAMA
            try
            {
                
                listBox1.Items.Clear();
                listBox2.Items.Clear();
                
            int x_degeri, y_degeri, kosul;
            int x_carpan = 0, y_carpan = 0;
            //dışardan deger alma
            
            x_degeri = Convert.ToInt32(textBox1.Text);
            
            y_degeri = Convert.ToInt32(textBox2.Text);
           
           
            
            //işlem kısmı
            kosul = 1;
            while (kosul < x_degeri)
            {
                if (x_degeri % kosul == 0)
                {
                    listBox1.Items.Add(kosul.ToString());
                    x_carpan = x_carpan + kosul;
                    
                }
                kosul++;    
            }
            textBox4.Text = x_carpan.ToString();
            kosul = 1;
            while ( kosul < y_degeri)
            {
                if (y_degeri % kosul == 0)
                {
                    listBox2.Items.Add(kosul.ToString());
                    y_carpan = y_carpan + kosul;   
                }
                kosul++;
            }
            textBox5.Text = y_carpan.ToString();

            if (x_carpan == y_degeri && y_carpan == x_degeri)
            {
                textBox3.Text = "DOST SAYIDIR..!";
            }
            else
            {
                textBox3.Text = "DOST SAYI DEĞİLDİR..!";
            }
            }
            catch (Exception)
            {
                MessageBox.Show("Texboxlara Sayı Girmez isen Sonuç Veremem :))");
                
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            textBox3.Text = "";
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
    }
}
