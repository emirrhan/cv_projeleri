#include "../include/brick.hpp"

Brick::Brick( Sprite s, int brickTextureID ) : Element( s ) {
    textureID = brickTextureID;
    crackedTexture.loadFromFile(allCrackedSkins[brickTextureID]);
    isBallHit = false;
}

void Brick::switchState() {
    if (isBallHit)
        destroy();
    else {
        isBallHit = true;
        crack();
    }
}

void Brick::destroy() {
    sprite.setPosition(1000,1000);
}

void Brick::crack() {
    sprite.setTexture(crackedTexture);
}