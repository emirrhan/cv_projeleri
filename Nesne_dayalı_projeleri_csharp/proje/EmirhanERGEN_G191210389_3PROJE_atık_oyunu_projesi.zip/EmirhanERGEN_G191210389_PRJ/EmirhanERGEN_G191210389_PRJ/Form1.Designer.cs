﻿namespace EmirhanERGEN_G191210389_PRJ
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timerKronometre = new System.Windows.Forms.Timer(this.components);
            this.listBox3Cam = new System.Windows.Forms.ListBox();
            this.camEkle = new System.Windows.Forms.Button();
            this.camDolum = new System.Windows.Forms.ProgressBar();
            this.panel6 = new System.Windows.Forms.Panel();
            this.camBosalt = new System.Windows.Forms.Button();
            this.listBox4Metal = new System.Windows.Forms.ListBox();
            this.metalEkle = new System.Windows.Forms.Button();
            this.metalDolum = new System.Windows.Forms.ProgressBar();
            this.metalBosalt = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.listBox2Kagit = new System.Windows.Forms.ListBox();
            this.kagıtEkle = new System.Windows.Forms.Button();
            this.kagıtDolum = new System.Windows.Forms.ProgressBar();
            this.kagıtBosalt = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.listBox1Organik = new System.Windows.Forms.ListBox();
            this.organikDolum = new System.Windows.Forms.ProgressBar();
            this.organikBosalt = new System.Windows.Forms.Button();
            this.organikEkle = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.basla = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.Label2puan = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Label1kronometre = new System.Windows.Forms.Label();
            this.bitir = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.resimBox = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.resimBox)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // timerKronometre
            // 
            this.timerKronometre.Interval = 1000;
            this.timerKronometre.Tick += new System.EventHandler(this.timer1KronometreTick_1);
            // 
            // listBox3Cam
            // 
            this.listBox3Cam.FormattingEnabled = true;
            this.listBox3Cam.Location = new System.Drawing.Point(20, 48);
            this.listBox3Cam.Name = "listBox3Cam";
            this.listBox3Cam.Size = new System.Drawing.Size(165, 199);
            this.listBox3Cam.TabIndex = 14;
            // 
            // camEkle
            // 
            this.camEkle.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.camEkle.FlatAppearance.BorderSize = 2;
            this.camEkle.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.camEkle.Font = new System.Drawing.Font("Tahoma", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.camEkle.ForeColor = System.Drawing.Color.Black;
            this.camEkle.Location = new System.Drawing.Point(20, 3);
            this.camEkle.Name = "camEkle";
            this.camEkle.Size = new System.Drawing.Size(165, 39);
            this.camEkle.TabIndex = 11;
            this.camEkle.Text = "CAM";
            this.camEkle.UseVisualStyleBackColor = true;
            this.camEkle.Click += new System.EventHandler(this.buttonEkleCam_Click);
            // 
            // camDolum
            // 
            this.camDolum.Location = new System.Drawing.Point(20, 253);
            this.camDolum.Name = "camDolum";
            this.camDolum.Size = new System.Drawing.Size(165, 23);
            this.camDolum.TabIndex = 13;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Teal;
            this.panel6.Controls.Add(this.listBox3Cam);
            this.panel6.Controls.Add(this.camEkle);
            this.panel6.Controls.Add(this.camDolum);
            this.panel6.Controls.Add(this.camBosalt);
            this.panel6.Location = new System.Drawing.Point(317, 347);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(200, 334);
            this.panel6.TabIndex = 8;
            // 
            // camBosalt
            // 
            this.camBosalt.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.camBosalt.FlatAppearance.BorderSize = 2;
            this.camBosalt.Font = new System.Drawing.Font("Tahoma", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.camBosalt.ForeColor = System.Drawing.Color.Black;
            this.camBosalt.Location = new System.Drawing.Point(20, 282);
            this.camBosalt.Name = "camBosalt";
            this.camBosalt.Size = new System.Drawing.Size(165, 46);
            this.camBosalt.TabIndex = 12;
            this.camBosalt.Text = "BOŞALT";
            this.camBosalt.UseVisualStyleBackColor = true;
            this.camBosalt.Click += new System.EventHandler(this.buttonBosaltCam_Click);
            // 
            // listBox4Metal
            // 
            this.listBox4Metal.FormattingEnabled = true;
            this.listBox4Metal.Location = new System.Drawing.Point(19, 48);
            this.listBox4Metal.Name = "listBox4Metal";
            this.listBox4Metal.Size = new System.Drawing.Size(165, 199);
            this.listBox4Metal.TabIndex = 18;
            // 
            // metalEkle
            // 
            this.metalEkle.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.metalEkle.FlatAppearance.BorderSize = 2;
            this.metalEkle.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.metalEkle.Font = new System.Drawing.Font("Tahoma", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.metalEkle.ForeColor = System.Drawing.Color.Black;
            this.metalEkle.Location = new System.Drawing.Point(19, 3);
            this.metalEkle.Name = "metalEkle";
            this.metalEkle.Size = new System.Drawing.Size(165, 39);
            this.metalEkle.TabIndex = 15;
            this.metalEkle.Text = "METAL";
            this.metalEkle.UseVisualStyleBackColor = true;
            this.metalEkle.Click += new System.EventHandler(this.buttonEkleMetal_Click);
            // 
            // metalDolum
            // 
            this.metalDolum.Location = new System.Drawing.Point(19, 253);
            this.metalDolum.Name = "metalDolum";
            this.metalDolum.Size = new System.Drawing.Size(165, 23);
            this.metalDolum.TabIndex = 17;
            // 
            // metalBosalt
            // 
            this.metalBosalt.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.metalBosalt.FlatAppearance.BorderSize = 2;
            this.metalBosalt.Font = new System.Drawing.Font("Tahoma", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.metalBosalt.ForeColor = System.Drawing.Color.Black;
            this.metalBosalt.Location = new System.Drawing.Point(19, 282);
            this.metalBosalt.Name = "metalBosalt";
            this.metalBosalt.Size = new System.Drawing.Size(165, 46);
            this.metalBosalt.TabIndex = 16;
            this.metalBosalt.Text = "BOŞALT";
            this.metalBosalt.UseVisualStyleBackColor = true;
            this.metalBosalt.Click += new System.EventHandler(this.buttonBosaltMetal_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Teal;
            this.panel5.Controls.Add(this.listBox4Metal);
            this.panel5.Controls.Add(this.metalEkle);
            this.panel5.Controls.Add(this.metalDolum);
            this.panel5.Controls.Add(this.metalBosalt);
            this.panel5.Location = new System.Drawing.Point(525, 347);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(200, 334);
            this.panel5.TabIndex = 11;
            // 
            // listBox2Kagit
            // 
            this.listBox2Kagit.FormattingEnabled = true;
            this.listBox2Kagit.Location = new System.Drawing.Point(19, 51);
            this.listBox2Kagit.Name = "listBox2Kagit";
            this.listBox2Kagit.Size = new System.Drawing.Size(165, 199);
            this.listBox2Kagit.TabIndex = 14;
            // 
            // kagıtEkle
            // 
            this.kagıtEkle.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.kagıtEkle.FlatAppearance.BorderSize = 2;
            this.kagıtEkle.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.kagıtEkle.Font = new System.Drawing.Font("Tahoma", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.kagıtEkle.ForeColor = System.Drawing.Color.Black;
            this.kagıtEkle.Location = new System.Drawing.Point(19, 6);
            this.kagıtEkle.Name = "kagıtEkle";
            this.kagıtEkle.Size = new System.Drawing.Size(165, 39);
            this.kagıtEkle.TabIndex = 11;
            this.kagıtEkle.Text = "KAĞIT";
            this.kagıtEkle.UseVisualStyleBackColor = true;
            this.kagıtEkle.Click += new System.EventHandler(this.buttonEkleKagit_Click);
            // 
            // kagıtDolum
            // 
            this.kagıtDolum.Location = new System.Drawing.Point(19, 256);
            this.kagıtDolum.Name = "kagıtDolum";
            this.kagıtDolum.Size = new System.Drawing.Size(165, 23);
            this.kagıtDolum.TabIndex = 13;
            // 
            // kagıtBosalt
            // 
            this.kagıtBosalt.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.kagıtBosalt.FlatAppearance.BorderSize = 2;
            this.kagıtBosalt.Font = new System.Drawing.Font("Tahoma", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.kagıtBosalt.ForeColor = System.Drawing.Color.Black;
            this.kagıtBosalt.Location = new System.Drawing.Point(19, 285);
            this.kagıtBosalt.Name = "kagıtBosalt";
            this.kagıtBosalt.Size = new System.Drawing.Size(165, 46);
            this.kagıtBosalt.TabIndex = 12;
            this.kagıtBosalt.Text = "BOŞALT";
            this.kagıtBosalt.UseVisualStyleBackColor = true;
            this.kagıtBosalt.Click += new System.EventHandler(this.buttonBosaltKagit_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Teal;
            this.panel4.Controls.Add(this.listBox2Kagit);
            this.panel4.Controls.Add(this.kagıtEkle);
            this.panel4.Controls.Add(this.kagıtDolum);
            this.panel4.Controls.Add(this.kagıtBosalt);
            this.panel4.Location = new System.Drawing.Point(525, 6);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(200, 335);
            this.panel4.TabIndex = 9;
            // 
            // listBox1Organik
            // 
            this.listBox1Organik.FormattingEnabled = true;
            this.listBox1Organik.Location = new System.Drawing.Point(20, 51);
            this.listBox1Organik.Name = "listBox1Organik";
            this.listBox1Organik.Size = new System.Drawing.Size(165, 199);
            this.listBox1Organik.TabIndex = 10;
            // 
            // organikDolum
            // 
            this.organikDolum.Location = new System.Drawing.Point(20, 256);
            this.organikDolum.Name = "organikDolum";
            this.organikDolum.Size = new System.Drawing.Size(165, 23);
            this.organikDolum.TabIndex = 9;
            // 
            // organikBosalt
            // 
            this.organikBosalt.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.organikBosalt.FlatAppearance.BorderSize = 2;
            this.organikBosalt.Font = new System.Drawing.Font("Tahoma", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.organikBosalt.ForeColor = System.Drawing.Color.Black;
            this.organikBosalt.Location = new System.Drawing.Point(20, 285);
            this.organikBosalt.Name = "organikBosalt";
            this.organikBosalt.Size = new System.Drawing.Size(165, 46);
            this.organikBosalt.TabIndex = 8;
            this.organikBosalt.Text = "BOŞALT";
            this.organikBosalt.UseVisualStyleBackColor = true;
            this.organikBosalt.Click += new System.EventHandler(this.buttonBosaltOrganik_Click);
            // 
            // organikEkle
            // 
            this.organikEkle.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.organikEkle.FlatAppearance.BorderSize = 2;
            this.organikEkle.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.organikEkle.Font = new System.Drawing.Font("Tahoma", 12.75F, System.Drawing.FontStyle.Bold);
            this.organikEkle.ForeColor = System.Drawing.Color.Black;
            this.organikEkle.Location = new System.Drawing.Point(20, 6);
            this.organikEkle.Name = "organikEkle";
            this.organikEkle.Size = new System.Drawing.Size(165, 39);
            this.organikEkle.TabIndex = 7;
            this.organikEkle.Text = "ORGANİK ATIK";
            this.organikEkle.UseVisualStyleBackColor = true;
            this.organikEkle.Click += new System.EventHandler(this.buttonEkleOrganik_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Teal;
            this.panel3.Controls.Add(this.listBox1Organik);
            this.panel3.Controls.Add(this.organikDolum);
            this.panel3.Controls.Add(this.organikBosalt);
            this.panel3.Controls.Add(this.organikEkle);
            this.panel3.Location = new System.Drawing.Point(317, 6);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(200, 335);
            this.panel3.TabIndex = 7;
            // 
            // basla
            // 
            this.basla.BackColor = System.Drawing.Color.Teal;
            this.basla.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.basla.ForeColor = System.Drawing.Color.White;
            this.basla.Location = new System.Drawing.Point(19, 11);
            this.basla.Name = "basla";
            this.basla.Size = new System.Drawing.Size(220, 80);
            this.basla.TabIndex = 11;
            this.basla.Text = "YENİ OYUN";
            this.basla.UseVisualStyleBackColor = false;
            this.basla.Click += new System.EventHandler(this.buttonYeniOyun_Click);
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Teal;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(19, 226);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(220, 50);
            this.label2.TabIndex = 10;
            this.label2.Text = "PUAN";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label2puan
            // 
            this.Label2puan.BackColor = System.Drawing.Color.White;
            this.Label2puan.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Label2puan.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2puan.ForeColor = System.Drawing.Color.MediumTurquoise;
            this.Label2puan.Location = new System.Drawing.Point(19, 276);
            this.Label2puan.Name = "Label2puan";
            this.Label2puan.Size = new System.Drawing.Size(220, 50);
            this.Label2puan.TabIndex = 9;
            this.Label2puan.Text = "0";
            this.Label2puan.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Teal;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(19, 110);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(220, 50);
            this.label3.TabIndex = 8;
            this.label3.Text = "SÜRE";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label1kronometre
            // 
            this.Label1kronometre.BackColor = System.Drawing.Color.White;
            this.Label1kronometre.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Label1kronometre.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1kronometre.ForeColor = System.Drawing.Color.MediumTurquoise;
            this.Label1kronometre.Location = new System.Drawing.Point(19, 160);
            this.Label1kronometre.Name = "Label1kronometre";
            this.Label1kronometre.Size = new System.Drawing.Size(220, 50);
            this.Label1kronometre.TabIndex = 7;
            this.Label1kronometre.Text = "60";
            this.Label1kronometre.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bitir
            // 
            this.bitir.BackColor = System.Drawing.Color.Teal;
            this.bitir.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bitir.ForeColor = System.Drawing.Color.White;
            this.bitir.Location = new System.Drawing.Point(19, 347);
            this.bitir.Name = "bitir";
            this.bitir.Size = new System.Drawing.Size(220, 80);
            this.bitir.TabIndex = 6;
            this.bitir.Text = "CIKIŞ";
            this.bitir.UseVisualStyleBackColor = false;
            this.bitir.Click += new System.EventHandler(this.buttonCikis_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.basla);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.Label2puan);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.Label1kronometre);
            this.panel2.Controls.Add(this.bitir);
            this.panel2.Location = new System.Drawing.Point(39, 241);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(253, 440);
            this.panel2.TabIndex = 6;
            // 
            // resimBox
            // 
            this.resimBox.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.resimBox.Location = new System.Drawing.Point(16, 13);
            this.resimBox.Name = "resimBox";
            this.resimBox.Size = new System.Drawing.Size(224, 203);
            this.resimBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimBox.TabIndex = 1;
            this.resimBox.TabStop = false;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.AntiqueWhite;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(317, -54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(408, 31);
            this.label1.TabIndex = 10;
            this.label1.Text = "ATIK KUTULARI";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.resimBox);
            this.panel1.Location = new System.Drawing.Point(42, 6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(253, 229);
            this.panel1.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(733, 692);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel6.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.resimBox)).EndInit();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer timerKronometre;
        private System.Windows.Forms.ListBox listBox3Cam;
        private System.Windows.Forms.Button camEkle;
        private System.Windows.Forms.ProgressBar camDolum;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button camBosalt;
        private System.Windows.Forms.ListBox listBox4Metal;
        private System.Windows.Forms.Button metalEkle;
        private System.Windows.Forms.ProgressBar metalDolum;
        private System.Windows.Forms.Button metalBosalt;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.ListBox listBox2Kagit;
        private System.Windows.Forms.Button kagıtEkle;
        private System.Windows.Forms.ProgressBar kagıtDolum;
        private System.Windows.Forms.Button kagıtBosalt;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.ListBox listBox1Organik;
        private System.Windows.Forms.ProgressBar organikDolum;
        private System.Windows.Forms.Button organikBosalt;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button basla;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label Label2puan;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label Label1kronometre;
        private System.Windows.Forms.Button bitir;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox resimBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button organikEkle;
    }
}

