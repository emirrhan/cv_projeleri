#include "../include/Element.hpp"

Element::Element( Sprite s ) {
  sprite = s;
}

Element::Element() {

}

Sprite Element::getSprite(){
  return sprite;
}

Vector2f Element::getPosition() {
    return sprite.getPosition();
}

FloatRect Element::getGlobalBounds() {
  return sprite.getGlobalBounds();
}

void Element::setPosition( int x, int y ) {
  sprite.setPosition(x, y);
}
