#include "../include/player.hpp"


Player::Player( Sprite s, int playerTextureID ) : DynamicElement( s ) {
    textureID = playerTextureID;
}

Player::Player() {

}

