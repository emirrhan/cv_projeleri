export const tabBackgroundColor = "#faf7f7";
export const tabIconColor = "#e63737";
export const searchBarBackgroundColor = "red";
export const headerColor = "#0C120C";
export const primaryColor = "#e63737";
export const secondaryColor = "#FFFFFC";
