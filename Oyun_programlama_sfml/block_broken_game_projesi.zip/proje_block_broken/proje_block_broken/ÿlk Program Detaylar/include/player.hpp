#ifndef _PLAYER_HPP__
#define _PLAYER_HPP__
#define ARRAY_LENGTH (6)

#define PLAYER_STARTING_POSITION_X (236)
#define PLAYER_STARTING_POSITION_Y (900)
#define PLAYER_SCALE_FACTOR_X      (0.25)
#define PLAYER_SCALE_FACTOR_Y      (0.25)
#define PLAYER_LENGTH              (464)

#include "DynamicElement.hpp"

// TODO: put ./Dependencies/bin/resimler into a define macro
class Player : public DynamicElement {
    public:
        // members
        int textureID;
        // methods
        Player( Sprite s, int playerTextureID );
        Player();
};

#endif // _PLAYER_HPP__
