#ifndef _DYNAMIC_ELEMENT_HPP_
#define _DYNAMIC_ELEMENT_HPP_

#include "Element.hpp"

class DynamicElement : public Element {
    public:
        DynamicElement( Sprite s);
        DynamicElement();
        void move( int x, int y);
};

#endif // _DYNAMIC_ELEMENT_HPP_
