export const firebaseConfig = {
  apiKey: "AIzaSyBpGMf5FivujDoamXSOpNUMwZPCThpXq84",
  authDomain: "recipeproject-f5595.firebaseapp.com",
  databaseURL: "https://recipeproject-f5595-default-rtdb.firebaseio.com",
  projectId: "recipeproject-f5595",
  storageBucket: "recipeproject-f5595.appspot.com",
  messagingSenderId: "718620250299",
  appId: "1:718620250299:web:7629e6a4d283b4aad5599e",
};
