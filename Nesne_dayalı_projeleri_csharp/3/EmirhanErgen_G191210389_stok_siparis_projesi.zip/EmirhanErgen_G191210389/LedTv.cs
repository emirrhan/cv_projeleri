﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmirhanErgen_G191210389
{
    public class LedTv : Urun
    {
        string EkranBoyutu;
        public string ekranBoyutu
        {
            get { return EkranBoyutu; }
            set { EkranBoyutu = value; }
        }
        string EkranCozunurlugu;
        public string ekranCozunurlugu
        {
            get { return EkranCozunurlugu; }
            set { EkranCozunurlugu = value; }
        }
        public LedTv()
        {

            lock (randomcu)
            {
                stokAdedi = rnd.Next(1, 100);
            }
            ad = "ASUS ROG STRIX";
            ekranBoyutu = "55 inç";
            ekranCozunurlugu = "3840x2160";
            hamFiyat = 34057;
            ozellik = "4K Görüntü 144hz Yenileme 4ms Tepkime Süresi RGB Aydınlatma";
            secilenAdet = 1;
            

        }
        public override int KdvUygula(int a)
        {
            a = (hamFiyat + (hamFiyat * 18) / 100) * secilenAdet;

            return a;
        }

    }
}
