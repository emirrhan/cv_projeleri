﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmirhanErgen_G191210389
{
    public class CepTel : Urun
    {
        string DahiliHafiza;
        public string dahiliHafiza
        {
            get { return DahiliHafiza; }
            set { DahiliHafiza = value; }
        }
        string RamKapasitesi;
        public string ramKapasitesi
        {
            get { return RamKapasitesi; }
            set { RamKapasitesi = value; }
        }
        string PilGucu;
        public string pilGucu
        {
            get { return PilGucu; }
            set { PilGucu = value; }
        }



        public CepTel()
        {

            lock (randomcu)
            {
                stokAdedi = rnd.Next(1, 100);
            }
            ad = "iPhone";
            dahiliHafiza = "512 GB";
            hamFiyat = 10599;
            marka = "11 Pro MAX";
            ozellik = "Super Retina XDR ekran ve Üçlü 12 MP Ultra Geniş, Geniş ve Telefoto kameralar";
            pilGucu = "3.969 mAh";
            ramKapasitesi = "4GB";
            secilenAdet = 1;


        }
        public override int KdvUygula(int a)
        {
            a = (hamFiyat + (hamFiyat * 20) / 100) * secilenAdet;

            return a;
        }
    }
}
